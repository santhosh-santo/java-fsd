import { ChangeColorDirectiveDirective } from './change-color-directive.directive';

describe('ChangeColorDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeColorDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
