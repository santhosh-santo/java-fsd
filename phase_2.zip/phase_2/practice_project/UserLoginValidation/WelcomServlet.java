

import jakarta.servlet.ServletException;
//import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
//import java.io.IOException; 
import java.io.PrintWriter; 
 

 
/** 
 * Servlet implementation class WelcomServlet 
 */ 
public class WelcomServlet extends HttpServlet { 
 private static final long serialVersionUID = 1L; 
        
    /** 
     * @see HttpServlet#HttpServlet() 
     */ 
    public WelcomServlet() { 
        super(); 
        // TODO Auto-generated constructor stub 
    } 
 
 /** 
  * @see HttpServlet#doGet(HttpServletRequest request, 
HttpServletResponse response) 
  */ 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        pw.print("<h1 align='center'> My Website</h1> <hr>");
        pw.print("<h4 align='center'> Log in successful</h4>");

        // Assuming "nextPage.html" is the next page you want to redirect to
        String nextPage = "C:\\Users\\Admin\\eclipse-web\\UserLoginValidation\\src\\main\\webapp\\Index.html";
        response.sendRedirect(nextPage);
    }
 
 /** 
  * @see HttpServlet#doPost(HttpServletRequest request, 
HttpServletResponse response) 
  */ 
 protected void doPost(HttpServletRequest request, HttpServletResponse 
response) throws ServletException, IOException { 
  // TODO Auto-generated method stub 
  //doGet(request, response); 
   
 } 
 
}

