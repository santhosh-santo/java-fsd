

import jakarta.servlet.ServletException;
//import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
//import java.io.IOException; 
import java.io.PrintWriter; 
 

/** 
 * Servlet implementation class UserServlet 
 */ 
public class UserServlet extends HttpServlet { 
 private static final long serialVersionUID = 1L; 
        
    /** 
     * @see HttpServlet#HttpServlet() 
     */ 
    public UserServlet() { 
        super(); 
        // TODO Auto-generated constructor stub 
    } 
 
 /** 
  * @see HttpServlet#doGet(HttpServletRequest request, 
HttpServletResponse response) 
  */ 
 protected void doGet(HttpServletRequest request, HttpServletResponse 
response) throws ServletException, IOException { 
  // TODO Auto-generated method stub 
  //response.getWriter().append("Served at: ").append(request.getContextPath()); 
	 
	 PrintWriter out = response.getWriter();

	    out.println("<html>");
	    out.println("<head>");
	    out.println("<title>Login Page</title>");
	    out.println("<style>");
	    out.println("    body { font-family: 'Arial', sans-serif; background-color: #f4f4f4; }");
	    out.println("    form { max-width: 300px; margin: 50px auto; padding: 20px; background: #fff; border-radius: 8px; box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); }");
	    out.println("    label { display: block; margin-bottom: 8px; }");
	    out.println("    input { width: 100%; padding: 10px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 4px; }");
	    out.println("    input[type=\"submit\"] { background-color: #4caf50; color: white; cursor: pointer; }");
	    out.println("</style>");
	    out.println("</head>");
	    out.println("<body>");

	    out.println("<h2 style=\"text-align: center;\">Login Form</h2>");
	    out.println("<form action=\"/UserLoginValidation/LoginServlet\" method=\"post\">");
	    out.println("    <label for=\"username\">Username:</label>");
	    out.println("    <input type=\"text\" id=\"username\" name=\"username\"><br>");
	    out.println("    <label for=\"password\">Password:</label>");
	    out.println("    <input type=\"password\" id=\"password\" name=\"password\"><br>");
	    out.println("    <input type=\"submit\" value=\"Login\">");
	    out.println("</form>");

	    out.println("</body>");
	    out.println("</html>");

	    out.close();
 } 
 
 /** 
  * @see HttpServlet#doPost(HttpServletRequest request, 
HttpServletResponse response) 
  */ 
 protected void doPost(HttpServletRequest request, HttpServletResponse 
response) throws ServletException, IOException { 
  // TODO Auto-generated method stub 
  //doGet(request, response); 
  String tname=request.getParameter("tname"); 
  String tpass=request.getParameter("tpass"); 
  response.setContentType("text/html"); 
  PrintWriter pw=response.getWriter(); 
  if (tname.equals("admin") && tpass.equals("Pass@123")){  
   response.sendRedirect("WelcomServlet"); 
  } 
  else { 
   pw.println("<h3>invalid credentials</h3>"); 
    
  } 
 } 
 
}