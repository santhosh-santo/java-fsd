package com.example.demo;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HobbyService {

    @Autowired
    HobbyRepository hobbyRepository;
    
    public String findByPersonId(int personid){
        hobbyRepository.findNameByPersonId(personid);
        return "find by PersonID" +personid;
    }  
    
    Logger log = Logger.getAnonymousLogger();
    public void addHobby(HobbyEntity he){
    	 log.info("HobbyEntity " + he);
    	    HobbyEntity savedEntity = hobbyRepository.save(he);
    	    log.info("Saved HobbyEntity: " + savedEntity);
    }
}
