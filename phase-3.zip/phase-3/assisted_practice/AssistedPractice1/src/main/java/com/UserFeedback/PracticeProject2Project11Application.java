package com.UserFeedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject2Project11Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject2Project11Application.class, args);
	}

}
