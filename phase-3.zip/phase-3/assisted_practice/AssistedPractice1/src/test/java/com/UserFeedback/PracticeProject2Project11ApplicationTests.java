package com.UserFeedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeProject2Project11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
