package project8;

public class Test  
{ 
    public static void main(String args[])  
    { 
        MountainBike mb = new MountainBike(6, 120, 155); 
        System.out.println(mb.toString());
    } 
}