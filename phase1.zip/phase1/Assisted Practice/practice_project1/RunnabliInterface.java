package trd;

class  Printer1 implements Runnable  {
	
	 @Override
	    public void run() {
	        System.out.println("Program executed through runnable interface");
	    }
}

public class RunnabliInterface  {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Printer1 p1 = new Printer1();
        Thread t = new Thread(p1);
        t.start();

	}

}
