package trd;

class Printer extends Thread {
	
	 @Override
	    public void run() {
	        System.out.println("Program executed through Thread Class");
	    }
}

public class ThreadsClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Printer p = new Printer();
        Thread t=new Thread(p);
        t.start();

	}

}
