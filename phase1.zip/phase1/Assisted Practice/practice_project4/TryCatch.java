package trycatch;

public class TryCatch {

	public static void main(String[] args) {
		
        int[] array = new int[4];
        try 
        {
            //array[2] = 4;
            array[5] = 4;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds occured!"); 
        }
        finally 
        {
            System.out.println("The array is of size " + array.length);
        }
		

	}

}
