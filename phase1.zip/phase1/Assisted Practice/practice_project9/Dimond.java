package dimond;
interface First 
{  
    default void show() 
    { 
        System.out.println("first run sucessfully"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("Second run sucessfully"); 
    } 
} 

public class Dimond implements First, Second  {
	
	public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
    	Dimond ob = new Dimond(); 
        ob.show(); 
    } 

}
