package emailvalidation;

import java.util.regex.Pattern;

public class EmailValidation {
	
	public static boolean isValid(String email)
	 {
	 String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" +
	 "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
	 Pattern pat = Pattern.compile(emailRegex);
	 if (email == null)
	 return false;
	 return pat.matcher(email).matches();
	 }
	
	public static void main(String[] args) {
		 String email1 = "sathiya@gmail.com";
		String email2 = "saran.com";
		String email3 = "aravind54@gmail.com";
		String email4 = "ramanujam@gmailcom";
		 String[] emails= {email1,email2,email3,email4};
		 for (int i = 0; i < emails.length; i++) {
		 String email=emails[i];
		if (isValid(email)) {
		 System.out.println(email+" is valid email");
		} else {
		 System.out.println(email+" is invalid email");
		 System.out.println();
		}
	}
		 }
}
	
	


