package callbyvalue;

public class CallByValue {

	public static void main(String[] args) {
		
		int number = 1;
        System.out.println("Before calling method: " + number);

        
        modifyValue(number);

        System.out.println("After calling method: " + number);
    }

    
    static void modifyValue(int x) {
        System.out.println("Inside method (before modification): " + x);
        x = 2;
        System.out.println("Inside method (after modification): " + x);

	}

}
