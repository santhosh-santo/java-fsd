package methodoverloading;

public class MethodOverloading {
	
	public static void main(String[] args) {
        
        displayInfo("Rahul");
        displayInfo(25);
        displayInfo("Rohit", 30);
    }

    
    static void displayInfo(String name) {
        System.out.println("Name: " + name);
    }

    
    static void displayInfo(int age) {
        System.out.println("Age: " + age);
    }

    
    static void displayInfo(String name, int age) {
        System.out.println("Name: " + name + ", Age: " + age);
    }

}
