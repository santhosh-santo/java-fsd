package callbyreference;


class Dog {
    String name;

    Dog(String name) {
        this.name = name;
    }
}

public class CallByReferenceClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Dog myDog = new Dog("Tomy");
	        System.out.println("Before calling method: " + myDog.name);

	        
	        modifyReference(myDog);

	        System.out.println("After calling method: " + myDog.name);

	}
	
	 static void modifyReference(Dog dog) {
	        System.out.println("Inside method (before modification): " + dog.name);
	        dog.name = "Roan";
	        System.out.println("Inside method (after modification): " + dog.name);
	    }

}
