package project;

import java.util.ArrayList;

public class Arraylist {
	public static void main(String[] args) {
        
        ArrayList<String> list = new ArrayList<>();
        list.add("Car");
        list.add("Bike");
        list.add("Bus");
        System.out.println("ArrayList: " + list);

}
}
