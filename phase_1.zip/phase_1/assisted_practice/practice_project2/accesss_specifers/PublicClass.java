package publicclass;

public class PublicClass {

	
	 public float publicVariable = 700.3f;

	    public void publicMethod() {
	        System.out.println("Public method called");
	    }

	    public static void main(String[] args) {
	        PublicClass publicObj = new PublicClass();
	        System.out.println("Accessing public variable: " + publicObj.publicVariable);
	        publicObj.publicMethod();
	    }
}
