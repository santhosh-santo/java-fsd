package protrctedclass;

public class ProtectedClass {
	
	protected int protectedVariable = 70;

    protected void protectedMethod() {
        System.out.println("Protected method called");
    }

	public static void main(String[] args) {
		
		ProtectedClass protectedObj = new ProtectedClass();
        System.out.println("Accessing protected variable: " + protectedObj.protectedVariable);
        protectedObj.protectedMethod();
		

	}

}
