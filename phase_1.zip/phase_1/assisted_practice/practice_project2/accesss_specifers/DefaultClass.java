package defaultclass;

public class DefaultClass {
	
	int defaultVariable = 20;

    void defaultMethod() {
        System.out.println("Default method called");
    }

	public static void main(String[] args) {
		
		 DefaultClass defaultObj = new DefaultClass();
	        System.out.println("Accessing default variable: " + defaultObj.defaultVariable);
	        defaultObj.defaultMethod();
		

	}

}
