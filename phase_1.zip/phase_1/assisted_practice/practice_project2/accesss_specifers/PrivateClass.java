package privateclass;

public class PrivateClass {
	
	private int privateVariable = 10;

    private void privateMethod() {
        System.out.println("Private method called");
    }

	public static void main(String[] args) {
		
		PrivateClass privateObj = new PrivateClass();
        System.out.println("Accessing private variable: " + privateObj.privateVariable);
        privateObj.privateMethod();
		

	}

}
