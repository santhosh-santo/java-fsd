package mapdemo;


import java.util.HashMap;
import java.util.Map;


public class MapDemo {

	public static void main(String[] args) {
		
		
		 Map<String, Integer> studentGrades = new HashMap<>();

	        
	        studentGrades.put("Rohit", 85);
	        studentGrades.put("Kholi", 92);
	        studentGrades.put("Rahul", 78);

	        
	        System.out.println("Student Grades:");
	        for (Map.Entry<String, Integer> entry : studentGrades.entrySet()) {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }

	        
	        String studentName = "Pant";
	        if (studentGrades.containsKey(studentName)) {
	            int grade = studentGrades.get(studentName);
	            System.out.println(studentName + "'s grade: " + grade);
	        } else {
	            System.out.println(studentName + " not found in the map.");
	        }

	}

}
