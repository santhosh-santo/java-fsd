package Constructor;

public class ParameterizedConstructor {
	
	public ParameterizedConstructor(String message) {
        System.out.println("Parameterized constructor called with message: " + message);
    }

    public static void main(String[] args) {
        // Create an instance of the class with a parameterized constructor
        ParameterizedConstructor obj = new ParameterizedConstructor("Hello Constructor");
    }

}
