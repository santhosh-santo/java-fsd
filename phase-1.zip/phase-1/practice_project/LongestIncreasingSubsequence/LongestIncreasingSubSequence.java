package longestincreasingsubsequence;

import java.util.Arrays;

public class LongestIncreasingSubSequence {

	public static void main(String[] args) {
		
		int[] numbers = generateRandomNumbers(10, 1, 50);
		System.out.println("Original Array: " + Arrays.toString(numbers));
		int[] lis = findLongestIncreasingSubsequence(numbers);
	    System.out.println("Longest Increasing Subsequence: " + Arrays.toString(lis));
		

	}
	
	 private static int[] generateRandomNumbers(int size, int min, int max) {
	        int[] numbers = new int[size];
	        for (int i = 0; i < size; i++) {
	            numbers[i] = (int) (Math.random() * (max - min + 1) + min);
	        }
	        return numbers;
	    }

	    // Method to find the longest increasing subsequence
	    private static int[] findLongestIncreasingSubsequence(int[] numbers) {
	        int n = numbers.length;
	        int[] lis = new int[n];
	        Arrays.fill(lis, 1);

	        for (int i = 1; i < n; i++) {
	            for (int j = 0; j < i; j++) {
	                if (numbers[i] > numbers[j] && lis[i] < lis[j] + 1) {
	                    lis[i] = lis[j] + 1;
	                }
	            }
	        }

	        int maxLength = 0;
	        int maxIndex = 0;

	        for (int i = 0; i < n; i++) {
	            if (lis[i] > maxLength) {
	                maxLength = lis[i];
	                maxIndex = i;
	            }
	        }

	        int[] longestIncreasingSubsequence = new int[maxLength];
	        longestIncreasingSubsequence[--maxLength] = numbers[maxIndex];

	        for (int i = maxIndex - 1; i >= 0; i--) {
	            if (numbers[i] < numbers[maxIndex] && lis[i] == lis[maxIndex] - 1) {
	                longestIncreasingSubsequence[--maxLength] = numbers[i];
	                maxIndex = i;
	            }
	        }

	        return longestIncreasingSubsequence;

	 }
}
