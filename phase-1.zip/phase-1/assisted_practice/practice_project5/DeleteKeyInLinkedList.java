package phase1;

class Node {
    int data;
    Node next;

    // Constructor to create a new node with given data
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

// LinkedList class represents the singly linked list
class LinkedList {
    Node head; 

    // Constructor to initialize an empty linked list
    LinkedList() {
        head = null;
    }

    // Method to insert a new node at the end of the linked list
    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Method to delete the first occurrence of a key in the linked list
    void deleteKey(int key) {
        Node current = head;
        Node prev = null;

        // Check if the key is in the head node
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key in the remaining nodes
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key is not present in the linked list
        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        // Unlink the node containing the key
        prev.next = current.next;
    }

    // Method to print the linked list
    void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DeleteKeyInLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList linkedList = new LinkedList();

        
        linkedList.insert(10);
        linkedList.insert(20);
        linkedList.insert(30);
        linkedList.insert(40);

        System.out.println("Original Linked List:");
        linkedList.printList();

        
        linkedList.deleteKey(20);

       
        System.out.println("Linked List after deleting the first occurrence of key 20:");
        linkedList.printList();


	}

}
