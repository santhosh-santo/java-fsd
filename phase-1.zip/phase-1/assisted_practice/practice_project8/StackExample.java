package phase1;
import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		
		Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack (push)
        pushElement(stack, 10);
        pushElement(stack, 20);
        pushElement(stack, 30);
        pushElement(stack, 40);

        // Display the elements in the stack
        displayStack(stack);

        // Remove elements from the stack (pop)
        popElement(stack);
        popElement(stack);

        // Display the elements in the stack after removal
        displayStack(stack);
    }

    // Method to insert an element into the stack (push)
    private static void pushElement(Stack<Integer> stack, int element) {
        System.out.println("Pushing element: " + element);
        stack.push(element);
    }

    // Method to remove an element from the stack (pop)
    private static void popElement(Stack<Integer> stack) {
        if (!stack.isEmpty()) {
            int removedElement = stack.pop();
            System.out.println("Popped element: " + removedElement);
        } else {
            System.out.println("Stack is empty. Cannot pop.");
        }
    }

    // Method to display the elements in the stack
    private static void displayStack(Stack<Integer> stack) {
        System.out.println("Elements in the stack:");
        for (Integer element : stack) {
            System.out.print(element + " ");
        }
        System.out.println();

	}

}
