package phase1;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {

	public static void main(String[] args) {
		
		Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue (enqueue)
        enqueueElement(queue, 10);
        enqueueElement(queue, 20);
        enqueueElement(queue, 30);
        enqueueElement(queue, 40);

        // Display the elements in the queue
        displayQueue(queue);

        // Remove elements from the queue (dequeue)
        dequeueElement(queue);
        dequeueElement(queue);

        // Display the elements in the queue after removal
        displayQueue(queue);
    }

    // Method to insert an element into the queue (enqueue)
    private static void enqueueElement(Queue<Integer> queue, int element) {
        System.out.println("Enqueuing element: " + element);
        queue.add(element);
    }

    // Method to remove an element from the queue (dequeue)
    private static void dequeueElement(Queue<Integer> queue) {
        if (!queue.isEmpty()) {
            int removedElement = queue.poll();
            System.out.println("Dequeuing element: " + removedElement);
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
        }
    }

    // Method to display the elements in the queue
    private static void displayQueue(Queue<Integer> queue) {
        System.out.println("Elements in the queue:");
        for (Integer element : queue) {
            System.out.print(element + " ");
        }
        System.out.println();
		

	}

}
