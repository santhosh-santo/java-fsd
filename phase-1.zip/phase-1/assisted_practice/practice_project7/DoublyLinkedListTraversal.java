package phase1;

class Nodes {
    int data;
    Nodes prev;
    Nodes next;

    // Constructor to create a new node with given data
    Nodes(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

// DoublyLinkedList class represents the doubly linked list
class DoublyLinkedList {
    Nodes head; 

    // Constructor to initialize an empty doubly linked list
    DoublyLinkedList() {
        head = null;
    }

    // Method to insert a new node at the end of the doubly linked list
    void insert(int data) {
        Nodes newNode = new Nodes(data);
        if (head == null) {
            head = newNode;
        } else {
            Nodes current = head;
            while (current.next != null) {
                current = current.next;
            }
            newNode.prev = current;
            current.next = newNode;
        }
    }

    // Method to traverse the doubly linked list in the forward direction
    void traverseForward() {
        Nodes current = head;
        System.out.println("Doubly Linked List (Forward):");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Method to traverse the doubly linked list in the backward direction
    void traverseBackward() {
        Nodes current = head;
        while (current != null && current.next != null) {
            current = current.next;
        }

        System.out.println("Doubly Linked List (Backward):");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}


public class DoublyLinkedListTraversal {

	public static void main(String[] args) {
		
		 DoublyLinkedList doublyLinkedList = new DoublyLinkedList();

	       
	        doublyLinkedList.insert(10);
	        doublyLinkedList.insert(20);
	        doublyLinkedList.insert(30);
	        doublyLinkedList.insert(40);

	        
	        doublyLinkedList.traverseForward();

	        
	        doublyLinkedList.traverseBackward();

	}

}
