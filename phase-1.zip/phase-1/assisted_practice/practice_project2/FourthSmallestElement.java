package phase1;

import java.util.Arrays;
import java.util.Scanner;

public class FourthSmallestElement {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the size of the array
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Create an array of the specified size
        int[] arr = new int[size];

        // Prompt the user to enter array elements
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            arr[i] = scanner.nextInt();
        }

        
        int fourthSmallest = findFourthSmallestElement(arr);

        
        System.out.println("Array: " + Arrays.toString(arr));

        
        System.out.println("Fourth Smallest Element: " + fourthSmallest);

        
        scanner.close();
    }

    private static int findFourthSmallestElement(int[] arr) {
        
        if (arr.length < 4) {
            System.out.println("Array should have at least four elements.");
            return -1; // Return a sentinel value to indicate an error
        }

        
        Arrays.sort(arr);

        
        return arr[3];
		

	}

}
