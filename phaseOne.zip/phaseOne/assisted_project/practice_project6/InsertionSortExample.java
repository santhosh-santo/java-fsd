package phaseone;

import java.util.Arrays;


public class InsertionSortExample {

	public static void main(String[] args) {
		
		int[] array = {88, 99, 158, 20, 101};

        // Display the original array
        System.out.println("Original Array: " + Arrays.toString(array));

        // Perform insertion sort
        insertionSort(array);

        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(array));
    }

    // Insertion sort method
    private static void insertionSort(int[] array) {
        int n = array.length;

        // Traverse the array
        for (int i = 1; i < n; ++i) {
            int key = array[i];
            int j = i - 1;

            // Move elements of array[0..i-1] that are greater than key to one position ahead of their current position
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j = j - 1;
            }

            // Place the key at its correct position in the sorted array
            array[j + 1] = key;
        }
		

	}

}
