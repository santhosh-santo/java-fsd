package phaseone;

import java.util.Scanner;

public class LinearSearchExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] array = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

        // Display the array elements
        System.out.println("Array elements: ");
        for (int num : array) {
            System.out.print(num + " ");
        }

        // Prompt the user to enter the element to search
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter the element to search: ");
        int key = scanner.nextInt();

        // Perform linear search
        int position = linearSearch(array, key);

        // Display the result of the search
        if (position != -1) {
            System.out.println("Element " + key + " found at position " + (position + 1));
        } else {
            System.out.println("Element " + key + " not found in the array");
        }

        // Close the Scanner to avoid resource leak
        scanner.close();
    }

    // Linear search method
    private static int linearSearch(int[] array, int key) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == key) {
                return i; // Element found, return its position
            }
        }
        return -1; 

	}

}
