package phaseone;

import java.util.Scanner;


public class BinarySearchExample {

	public static void main(String[] args) {
		
		
		int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        // Display the sorted array elements
        System.out.println("Sorted Array elements: ");
        for (int num : array) {
            System.out.print(num + " ");
        }

        // Prompt the user to enter the element to search
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter the element to search: ");
        int key = scanner.nextInt();

        // Perform binary search
        int position = binarySearch(array, key);

        // Display the result of the search
        if (position != -1) {
            System.out.println("Element " + key + " found at position " + (position + 1));
        } else {
            System.out.println("Element " + key + " not found in the array");
        }

        // Close the Scanner to avoid resource leak
        scanner.close();
    }

    // Binary search method
    private static int binarySearch(int[] array, int key) {
        int low = 0;
        int high = array.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;

            if (array[mid] == key) {
                return mid; // Element found, return its position
            } else if (array[mid] < key) {
                low = mid + 1; // Search in the right half
            } else {
                high = mid - 1; // Search in the left half
            }
        }

        return -1;

	}

}
