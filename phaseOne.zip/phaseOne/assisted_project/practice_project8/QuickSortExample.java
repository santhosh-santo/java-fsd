package phaseone;

import java.util.Arrays;

public class QuickSortExample {

	public static void main(String[] args) {
		
		int[] array = {308, 270, 483, 311, 149, 882, 120};

        // Display the original array
        System.out.println("Original Array: " + Arrays.toString(array));

        // Perform quick sort
        quickSort(array, 0, array.length - 1);

        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(array));
    }

    // Quick sort method
    private static void quickSort(int[] array, int low, int high) {
        if (low < high) {
            // Partition the array and get the pivot element index
            int pivotIndex = partition(array, low, high);

            // Recursively sort the subarrays before and after the pivot
            quickSort(array, low, pivotIndex - 1);
            quickSort(array, pivotIndex + 1, high);
        }
    }

    // Partition method to find the pivot element index
    private static int partition(int[] array, int low, int high) {
        // Choose the rightmost element as the pivot
        int pivot = array[high];

        // Index of the smaller element
        int i = low - 1;

        // Traverse the array and rearrange elements
        for (int j = low; j < high; j++) {
            if (array[j] <= pivot) {
                i++;

                // Swap array[i] and array[j]
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        // Swap array[i + 1] and array[high] (place the pivot in its correct position)
        int temp = array[i + 1];
        array[i + 1] = array[high];
        array[high] = temp;

        // Return the pivot element index
        return i + 1;

	}

}
