package phaseone;

import java.util.Scanner;

public class ExponentialSearchExample {

	public static void main(String[] args) {
		
		
		 int[] array = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

	        // Display the sorted array elements
	        System.out.println("Sorted Array elements: ");
	        for (int num : array) {
	            System.out.print(num + " ");
	        }

	        // Prompt the user to enter the element to search
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("\nEnter the element to search: ");
	        int key = scanner.nextInt();

	        // Perform exponential search
	        int position = exponentialSearch(array, key);

	        // Display the result of the search
	        if (position != -1) {
	            System.out.println("Element " + key + " found at position " + (position + 1));
	        } else {
	            System.out.println("Element " + key + " not found in the array");
	        }

	        // Close the Scanner to avoid resource leak
	        scanner.close();
	    }

	    // Exponential search method
	    private static int exponentialSearch(int[] array, int key) {
	        int n = array.length;

	        // If the key is present at the first position
	        if (array[0] == key) {
	            return 0;
	        }

	        // Find the range for binary search by repeatedly doubling the index
	        int i = 1;
	        while (i < n && array[i] <= key) {
	            i *= 2;
	        }

	        // Perform binary search in the identified range
	        return binarySearch(array, key, i / 2, Math.min(i, n - 1));
	    }

	    // Binary search method
	    private static int binarySearch(int[] array, int key, int low, int high) {
	        while (low <= high) {
	            int mid = (low + high) / 2;

	            if (array[mid] == key) {
	                return mid; // Element found, return its position
	            } else if (array[mid] < key) {
	                low = mid + 1; // Search in the right half
	            } else {
	                high = mid - 1; // Search in the left half
	            }
	        }

	        return -1; 

	}

}
